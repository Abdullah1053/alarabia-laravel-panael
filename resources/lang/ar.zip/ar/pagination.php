<?php return  array (
  'previous' => '&laquo; السابق',
  'next' => 'التالي &raquo;',
);